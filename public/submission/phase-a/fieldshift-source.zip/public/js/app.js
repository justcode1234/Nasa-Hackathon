import { api, getTransport } from './lib/api.js';
import { initMap } from './modules/map.js';
import { renderEvidence } from './modules/data-flow.js';
import { renderStrategy } from './modules/strategy.js';
import { renderCatalog, updateCropChoices } from './modules/si.js';
import { initTabs } from './lib/tabs.js';
import { initContext } from './modules/context.js';
import { initChat } from './modules/chat.js';
import { resolveCropInput } from './modules/workflow-assistant.js';
import { comparisonReadiness } from './lib/comparison-readiness.js';

const $ = selector => document.querySelector(selector);
$('#runtime-status').textContent = getTransport() === 'http' ? 'Node.js testing mode' : 'Runs in your browser · no account needed';
let observations = null;
let comparedInputs = null;
let catalogReady = false;
let catalogFailed = false;
let comparing = false;
let revision = 0;
let controller;
let catalogData, countryCrops = null, selectedFarm = null, pestContext = null, soilContext = null, waterContext = null, context, chat;
const activateTab = initTabs();
const year = new Date().getUTCFullYear();
$('#reference-year').value = year - 1;
$('#reference-year').max = year - 1;
$('#planning-year').value = Math.min(2100, year + 1);
for (let month = 1; month <= 12; month++) {
  const option = document.createElement('option');
  option.value = month;
  option.textContent = new Intl.DateTimeFormat('en', { month: 'long', timeZone: 'UTC' }).format(new Date(Date.UTC(2000, month - 1, 1)));
  $('#start-month').append(option);
}
function status(selector, message, error = false) {
  const node = $(selector);
  node.textContent = message;
  node.classList.toggle('error', error);
}
function syncControls() {
  const gate = getComparisonReadiness();
  $('#compare').disabled = !gate.ready || comparing;
  $('#compare').setAttribute('aria-describedby', 'comparison-readiness');
  $('#comparison-readiness').textContent = gate.message;
  const planning = !$('#si').hidden;
  $('#flow-blocker').hidden = !planning || gate.ready;
  $('#flow-blocker').textContent = gate.ready ? '' : gate.message;
  $('#flow-next').disabled = planning && (gate.code === 'catalog' || comparing);
  if (planning) $('#flow-next').textContent = comparing ? 'Comparing…' : gate.label;
  $('#flow-next').setAttribute('aria-describedby', planning && !gate.ready ? 'flow-blocker' : 'flow-progress');
}
function getComparisonReadiness() {
  return comparisonReadiness({catalogReady,catalogFailed,country:countryCrops,observations,
    allowedCount:document.querySelectorAll('[name="allowedCrops"]:checked').length});
}
window.addEventListener('fieldshift:tabchange', syncControls);
function invalidate(clearEvidence, options = {}) {
  revision++;
  controller?.abort();
  comparing = false;
  comparedInputs = null;
  chat?.invalidate(options);
  $('#strategy-output').textContent = 'Inputs changed. Compare again to see results for the current inputs.';
  status('#comparison-status', clearEvidence ? 'Load evidence for the selected coordinates and year.' : 'Constraints changed. Compare again.');
  if (clearEvidence) {
    observations = null;
    $('#retry-evidence').hidden = true;
    $('#evidence-output').replaceChildren();
    status('#evidence-status', 'Location or reference year changed. Load historical NASA evidence.');
  }
  $('#load-evidence').disabled = false;
  syncControls();
}
function selectLocation(latitude, longitude, options = {}) {
  $('#latitude').value = latitude;
  $('#longitude').value = longitude;
  $('#example-location').value = '';
  invalidate(true, options);
  map.setLocation(latitude, longitude, options.pan ?? false);
  return context?.locationChanged(options);
}
const map = initMap((latitude, longitude) => selectLocation(latitude, longitude), id => context.selectFarm(id));
context = initContext({ map, selectLocation,
  coordinates: () => $('#latitude').value !== '' && $('#longitude').value !== '' && $('#latitude').checkValidity() && $('#longitude').checkValidity() ?
    { latitude: Number($('#latitude').value), longitude: Number($('#longitude').value) } : null,
  onFarm: (farm, options = {}) => {
    selectedFarm = farm;
    if (catalogData) updateCropChoices(catalogData, farm?.crops ?? [], countryCrops);
    $('#recorded-crops').textContent = farm ? `Selected field: ${farm.name}. ${farm.crops.length ? `Recorded crop tags: ${farm.crops.join(', ')}. They are available as unassessed choices.` : 'No crop tags are recorded.'} A current tag does not establish rotation history.` : 'Choose crops yourself; a map tag does not provide a three-crop rotation history.';
    chat?.invalidate(options);
  }, onPests: (data, options = {}) => { pestContext = data; chat?.invalidate(options); },
  onSoil: data => { soilContext = data; }, onWater: data => { waterContext = data; },
  onCountrySelection: (options = {}) => { $('#latitude').value = ''; $('#longitude').value = ''; map.clearLocation(); invalidate(true, options); },
  onCountry: (data, options = {}) => {
    const changed = countryCrops?.country !== data?.country;
    countryCrops = data;
    if (catalogData) renderCatalog(catalogData, countryCrops, selectedFarm?.crops ?? []);
    if (changed && observations) invalidate(false, options);
    syncControls();
  }
});
chat = initChat(() => ({ inputs: comparedInputs, country: countryCrops?.country ?? '', observations, farm: selectedFarm,
  pests: pestContext, soil: soilContext, water: waterContext,
  location: $('#latitude').value !== '' && $('#longitude').value !== '' && $('#location-form').checkValidity() ?
    { latitude: Number($('#latitude').value), longitude: Number($('#longitude').value) } : null,
  planning: readInputs(), countryCrops, catalog: catalogData, farms: context.getFarms(),
  regionCode: $('#place-region').value === '__all__' ? null : $('#place-region').value || null }), {
  chooseCountry: code => context.chooseCountry(code, { fromAssistant: true }),
  chooseRegion: code => context.chooseRegion(code, { fromAssistant: true }),
  chooseLocation: (point, countryCode) => selectLocation(point.latitude, point.longitude, { pan: true, countryCode, fromAssistant: true }),
  chooseFarm: id => context.selectFarm(id, { fromAssistant: true }),
  loadFarms: () => context.loadFarms(),
  showStep: activateTab, loadEvidence: () => loadEvidence({ fromAssistant: true }),
  compare: () => runComparison({ fromAssistant: true }),
  applyPlanning({ baseline, constraints, allowed }) {
    if (!catalogData || !countryCrops?.country) throw new Error('Country crop evidence is not loaded.');
    if (baseline) baseline.forEach((name, index) => {
      const crop = resolveCropInput(name, catalogData, countryCrops);
      const select = $(`#baseline-${index + 1}`);
      if (![...select.options].some(option => option.value === crop.id)) select.add(new Option(`${crop.name} — farmer supplied / unassessed`, crop.id));
      select.value = crop.id;
    });
    const controls = { irrigation: '#irrigation', soil: '#soil', soilPh: '#soil-ph', priority: '#priority',
      planningYear: '#planning-year', startMonth: '#start-month', referenceYear: '#reference-year' };
    for (const [key, value] of Object.entries(constraints ?? {})) if (controls[key]) $(controls[key]).value = value;
    if (allowed) {
      const ids = allowed.map(name => resolveCropInput(name, catalogData, countryCrops).id);
      document.querySelectorAll('[name=allowedCrops]').forEach(input => { input.checked = ids.includes(input.value); });
    }
    invalidate(Boolean(constraints?.referenceYear), { fromAssistant: true });
  }
});
for (const id of ['#latitude', '#longitude']) $(id).addEventListener('input', () => {
  $('#example-location').value = '';
  invalidate(true);
  context.locationChanged();
  if ($('#latitude').value !== '' && $('#longitude').value !== '' && $('#latitude').checkValidity() && $('#longitude').checkValidity()) {
    map.setLocation(Number($('#latitude').value), Number($('#longitude').value));
  }
});
$('#reference-year').addEventListener('input', () => invalidate(true));
$('#example-location').addEventListener('change', () => {
  if (!$('#example-location').value) return;
  const [latitude, longitude] = $('#example-location').value.split(',').map(Number);
  const countryCode = { '52.19,0.09': 'GB', '-31.89,116.77': 'AU', '42,-93.69': 'US', '-0.77,36.42': 'KE' }[$('#example-location').value];
  $('#latitude').value = latitude;
  $('#longitude').value = longitude;
  invalidate(true);
  map.setLocation(latitude, longitude, true);
  context.locationChanged({ countryCode });
  context.loadFarms();
});
$('#planning-form').addEventListener('input', () => invalidate(false));
async function loadEvidence(options = {}) {
  if (!$('#location-form').checkValidity()) return false;
  const selectionVersion = revision;
  await context.ensureCountry(options);
  if (selectionVersion !== revision) return;
  invalidate(true, options);
  const version = revision;
  controller = new AbortController();
  $('#load-evidence').disabled = true;
  status('#evidence-status', 'Retrieving historical NASA POWER data… This may take up to 25 seconds.');
  activateTab('evidence');
  const params = new URLSearchParams({ latitude: $('#latitude').value, longitude: $('#longitude').value, year: $('#reference-year').value });
  try {
    const data = await api(`/api/observations?${params}`, { signal: controller.signal });
    if (revision !== version) return;
    observations = data;
    renderEvidence(data);
    status('#evidence-status', 'Historical evidence loaded. Inspect sources and missingness below.');
    status('#comparison-status', 'Enter the baseline and constraints, then compare.');
    activateTab('evidence');
    context.loadSoil();
    return true;
  } catch (error) {
    if (error.name !== 'AbortError' && revision === version) { status('#evidence-status', error.message, true); $('#retry-evidence').hidden = false; }
    return false;
  } finally {
    if (revision === version) { $('#load-evidence').disabled = false; syncControls(); }
  }
}
$('#location-form').addEventListener('submit', event => { event.preventDefault(); loadEvidence(); });
$('#retry-evidence').addEventListener('click', () => loadEvidence());
function readInputs() {
  return { latitude: Number($('#latitude').value), longitude: Number($('#longitude').value), referenceYear: Number($('#reference-year').value), country: countryCrops?.country ?? '',
    planningYear: Number($('#planning-year').value), startMonth: Number($('#start-month').value),
    baseline: [1, 2, 3].map(i => $(`#baseline-${i}`).value),
    allowedCrops: [...document.querySelectorAll('[name="allowedCrops"]:checked')].map(node => node.value),
    previousCrop: $('#previous-crop').value, irrigation: $('#irrigation').value, soil: $('#soil').value,
    pestHistory: $('#pest-history').value, priority: $('#priority').value,
    soilPh: $('#soil-ph').value === '' ? null : Number($('#soil-ph').value), drainage: $('#drainage').value };
}
activateTab.beforeNext = from => {
  if (from === 'location' && !observations) {
    if ($('#location-form').reportValidity()) $('#location-form').requestSubmit();
    return false;
  }
  if (from === 'si') {
    const gate = getComparisonReadiness();
    if (!gate.ready) {
      status('#comparison-status', gate.message, true);
      if (gate.code === 'country' || gate.code === 'coverage' || gate.code === 'evidence') {
        activateTab('location');
        $(gate.code === 'evidence' ? '#load-evidence' : '#pest-country').focus();
      } else if (gate.code === 'allowed') {
        $('#allowed-crops').closest('fieldset').scrollIntoView({block:'center'});
        document.querySelector('[name="allowedCrops"]')?.focus();
      }
      return false;
    }
    if ($('#planning-form').reportValidity()) $('#planning-form').requestSubmit();
    return false;
  }
};
async function runComparison(options = {}) {
  const gate = getComparisonReadiness();
  if (!gate.ready) { status('#comparison-status', gate.message, true); syncControls(); return false; }
  if (!$('#planning-form').checkValidity()) return false;
  invalidate(false, options);
  const version = revision;
  const inputs = readInputs();
  controller = new AbortController();
  comparing = true;
  syncControls();
  status('#comparison-status', 'Comparing sourced crop rules and historical evidence…');
  try {
    const result = await api('/api/compare', { method: 'POST', body: inputs, signal: controller.signal });
    if (version !== revision) return;
    renderStrategy(result);
    comparedInputs = inputs;
    status('#comparison-status', 'Baseline and two alternatives ready. Review the trade-offs in module 04.');
    status('#answer-status', 'Ask about a catalog crop, water, soil, pest limits or the comparison.');
    activateTab('strategy');
    return result;
  } catch (error) {
    if (error.name !== 'AbortError' && version === revision) status('#comparison-status', error.message, true);
    return false;
  } finally { if (version === revision) { comparing = false; syncControls(); } }
}
$('#planning-form').addEventListener('submit', event => { event.preventDefault(); runComparison(); });
try {
  const catalog = await api('/api/crops');
  catalogData = catalog;
  renderCatalog(catalog, countryCrops, selectedFarm?.crops ?? []);
  catalogReady = true;
  syncControls();
} catch (error) { catalogFailed = true; syncControls(); status('#catalog-status', `Crop catalog unavailable: ${error.message} Reload this page to retry.`, true); }
