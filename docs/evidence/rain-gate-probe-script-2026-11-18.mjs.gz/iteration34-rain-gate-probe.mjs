// METHOD: contextBlocks from ../public/js/lib/chat-context.js (the live shipped module), run 19 Nov with the
// app's own offline observations fixture. The weather branch sits behind TOPIC.weather, but the series
// selector inside it enumerates rain|rains|rainy and freeze|freezing|frosty, so a word can be handled by the
// branch and still be unable to reach it. Read-only, no expectations: this prints which questions get a
// paragraph and which series that paragraph quotes.
const modulePath = process.argv[2] ?? '../public/js/lib/chat-context.js';
const { contextBlocks } = await import(modulePath);
const observations = {
  period: { start: '2024-01-01', end: '2024-12-31' },
  dates: ['2024-06-01', '2024-06-02'],
  location: { latitude: -31.89, longitude: 116.77 },
  retrievedAt: '2025-02-01T00:00:00Z',
  source: { id: 'nasa-power', title: 'NASA POWER exact data request', url: 'https://example.invalid/power' },
  parameters: {
    T2M: { label: 'Mean air temperature', units: '°C', latestAvailableDate: '2024-06-02', values: [12.1, 12.9] },
    T2M_MIN: { label: 'Minimum air temperature', units: '°C', latestAvailableDate: '2024-06-02', values: [-1.4, -0.6] },
    PRECTOTCORR: { label: 'Rainfall', units: 'mm/day', latestAvailableDate: '2024-06-02', values: [0, 3.4] },
    ALLSKY_SFC_SW_DWN: { label: 'Solar irradiance', units: 'MJ/m^2/day', latestAvailableDate: '2024-06-02', values: [9.8, 10.2] }
  }
};
console.log(`METHOD: contextBlocks from ${modulePath}`);
const cases = [
  'Show me rainfall evidence', 'How much precipitation fell here?', 'What was the temperature here?',
  'Was there a frost?', 'Is there solar resource here?', 'NASA figures for this point',
  'How much rain fell here last year?', 'Did we get enough rain this season?', 'The rain came late.',
  'It was rainy in March.', 'Rain does not fall evenly here.', 'Did it freeze here in July?',
  'Is freezing common here?', 'A frosty night, is that likely?', 'How does the rain look for beans?'
];
let reached = 0;
for (const q of cases) {
  const blocks = contextBlocks(q, { observations }, { topic: 'conditions' }).blocks;
  const quoted = blocks[0]?.text.match(/^([^:]+):/)?.[1] ?? '(no paragraph)';
  if (blocks.length) reached++;
  console.log(`${quoted.padEnd(26)} :: ${q}`);
}
console.log(`REACHED ${reached}/${cases.length}`);
