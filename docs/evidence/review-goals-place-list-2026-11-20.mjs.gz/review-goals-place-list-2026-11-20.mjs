import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import path from 'node:path';

const root = process.cwd();
const load = name => import(pathToFileURL(path.join(root, name)).href);
const { createWorkflowAssistant, resolveCropInput } = await load('public/js/modules/workflow-assistant.js');
const { catalog } = await load('server/agronomy/catalog.js');
const { getCountryCrops } = await load('server/context/crops.js');
const { createLocationClient } = await load('server/context/locations.js');
const readShipped = async name => JSON.parse(await readFile(path.join(root, 'public/data/locations', name), 'utf8'));

async function walk(country, readJson) {
  const getLocations = createLocationClient({ readJson });
  const state = { country: '', catalog, countryCrops: null, farm: null, farms: [], regionCode: null,
    location: null, observations: null, planning: { baseline: ['', '', ''], allowedCrops: [],
      irrigation: 'unknown', soil: 'unknown', startMonth: 1, planningYear: 2026, referenceYear: 2025 } };
  const calls = [];
  const actions = {
    chooseCountry(code) { calls.push(`country:${code}`); state.country = code;
      state.countryCrops = getCountryCrops({ country: code });
      state.planning.allowedCrops = state.countryCrops.screeningCropIds; },
    chooseLocation(place) { calls.push('location'); state.location = { latitude: place.latitude, longitude: place.longitude }; },
    chooseRegion(id) { calls.push(`region:${id}`); state.regionCode = id; },
    chooseFarm(id) { calls.push('farm'); state.farm = state.farms.find(farm => farm.id === id); },
    loadFarms() { calls.push('fields'); return { ok: true, count: 0 }; },
    showStep(step) { calls.push(`step:${step}`); },
    applyPlanning({ baseline }) { calls.push('inputs');
      if (baseline) state.planning.baseline = baseline.map(n => resolveCropInput(n, catalog, state.countryCrops).id); },
    async loadEvidence() { calls.push('NASA'); return true; },
    compare() { calls.push('compare'); return { scenarios: [{ timeline: [] }] }; }
  };
  const assistant = createWorkflowAssistant({ getState: () => state, actions, fieldsGraceMs: 200,
    request: async requestPath => {
      const url = new URL(requestPath, 'http://localhost');
      assert.equal(url.pathname, '/api/locations');
      return getLocations({ country: url.searchParams.get('country') });
    } });
  const replies = [];
  for (const question of [`Help me plan a rotation in ${country}`, 'A specific area']) {
    const answer = await assistant.respond(question);
    replies.push({ question, text: answer.blocks.map(block => block.text).join(' ') });
  }
  return { calls, replies };
}

const raw = await readShipped('PH.json');
console.log('SHIPPED_PH_TOWNS', raw.places.length);
const refused = await walk('the Philippines', async name => {
  if (name === 'PH.json') throw new Error('Simulated saved-list read refusal');
  return readShipped(name);
});
const empty = await walk('Antarctica', readShipped);
const healthy = await walk('the Philippines', readShipped);
console.log(JSON.stringify({ refused, empty, healthy }, null, 2));
assert.match(refused.replies[1].text, /No towns are listed/);
assert.match(empty.replies[1].text, /No towns are listed/);
assert.doesNotMatch(healthy.replies[1].text, /No towns are listed/);
assert.equal(refused.replies[1].text.replaceAll('Philippines', '<country>'),
  empty.replies[1].text.replaceAll('Antarctica', '<country>'));
assert(!refused.calls.includes('location'));
console.log('DEFECT_REPRODUCED refusal and empty list share identical country-normalized wording');
console.log('SCOPE offline production assistant and location adapter; fake UI actions; no browser or live service');
