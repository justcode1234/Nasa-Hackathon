#!/usr/bin/env python3
"""Iteration 59 verification ladder re-executed on the exact bytes that will be committed.

The first ladder (red-1/green-1/attackA/attackB/green-2 in this same directory) ran against a copy of
tests/e2e/chat-refused-ask-keeps-question.spec.js whose header comment was four lines instead of five, so
every case in the shipped spec sits one line lower and the archived logs would name lines the committed file
does not have. This script therefore re-runs, in order:

  red       product bytes reverted to HEAD (no restore) + shipped spec   -> must fail test 1 at spec:54
  attackA   fixed product bytes minus the restore statement              -> must fail test 1 only
  attackB   fixed product bytes minus the empty-composer guard           -> must fail test 2 only
  green     fixed product bytes                                          -> must pass 8/8
  offline   npm test                                                     -> whole offline suite

Each step stamps the interpreter and the sha256 of public/js/modules/chat.js it actually built, refuses to
continue if a mutation does not apply exactly once, and always restores the fixed file before exiting.
"""
import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path('/Users/portbrain/Documents/Qoder/2026-11-18/80eab783/Nasa-Hackathon')
CHAT = ROOT / 'public/js/modules/chat.js'
SPEC = 'tests/e2e/chat-refused-ask-keeps-question.spec.js'
SCRATCH = ROOT / 'artifacts/scratch/iter59'
FIXED = SCRATCH / 'chat-fixed.js'
RESTORE = "        if ($('question').value === '') $('question').value = question;\n"
UNGUARDED = "        $('question').value = question;\n"
FIXED_SHA = '103dede5c2026f5fa49307c3923053c03e4aa4bc3010bb8d6fc04efe178fca89'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(cmd: list[str], log: Path, label: str) -> int:
    with log.open('w') as handle:
        handle.write(f'STEP {label}\n')
        handle.write(f'UTC {subprocess.run(["date", "-u", "+%Y-%m-%dT%H:%M:%SZ"], capture_output=True, text=True).stdout.strip()}\n')
        handle.write(subprocess.run(['node', '-p', "'INTERPRETER ' + process.version + ' ' + process.execPath"],
                                    capture_output=True, text=True).stdout)
        handle.write(f'CHAT_SHA256 {sha(CHAT)}\n')
        handle.write(f'COMMAND {" ".join(cmd)}\n\n')
        handle.flush()
        code = subprocess.call(cmd, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT)
        handle.write(f'\nEXIT={code}\n')
    print(f'{label}: exit {code}', flush=True)
    return code


def main() -> int:
    assert sha(FIXED) == FIXED_SHA, f'the fixed snapshot hashes to {sha(FIXED)}, not {FIXED_SHA}'
    assert CHAT.read_text() == FIXED.read_text(), 'the working copy is not the fixed snapshot'
    head = subprocess.run(['git', 'show', 'HEAD:public/js/modules/chat.js'], cwd=ROOT,
                          capture_output=True, text=True).stdout
    assert head, 'could not read the HEAD copy of chat.js'
    assert RESTORE in FIXED.read_text(), 'the restore statement is not in the fixed snapshot'

    failures = []
    try:
        # 1. red: HEAD bytes, shipped spec.
        CHAT.write_text(head)
        run(['npm', 'run', 'build'], SCRATCH / 'red-2-build.log', 'red-2-build')
        code = run(['npx', 'playwright', 'test', SPEC, '--output=artifacts/playwright/iter59-red2'],
                   SCRATCH / 'red-2-finalspec.log', 'red-2')
        if code == 0:
            failures.append('red run passed: the reverted bytes do not reproduce the lost message')

        # 2. attackA: the restore statement deleted.
        CHAT.write_text(FIXED.read_text().replace(RESTORE, '', 1))
        assert RESTORE not in CHAT.read_text(), 'attackA did not remove the restore statement'
        run(['npm', 'run', 'build'], SCRATCH / 'attackA2-build.log', 'attackA2-build')
        code = run(['npx', 'playwright', 'test', SPEC, '--output=artifacts/playwright/iter59-attackA2'],
                   SCRATCH / 'attackA2-finalspec.log', 'attackA2')
        if code == 0:
            failures.append('attackA passed: test 1 does not depend on the restore statement')

        # 3. attackB: the empty-composer guard dropped, so a refusal overwrites typed text.
        CHAT.write_text(FIXED.read_text().replace(RESTORE, UNGUARDED, 1))
        assert UNGUARDED in CHAT.read_text(), 'attackB did not replace the guarded restore'
        assert RESTORE not in CHAT.read_text(), 'attackB left the guard in place'
        run(['npm', 'run', 'build'], SCRATCH / 'attackB2-build.log', 'attackB2-build')
        code = run(['npx', 'playwright', 'test', SPEC, '--output=artifacts/playwright/iter59-attackB2'],
                   SCRATCH / 'attackB2-finalspec.log', 'attackB2')
        if code == 0:
            failures.append('attackB passed: test 2 does not depend on the empty-composer guard')
    finally:
        CHAT.write_text(FIXED.read_text())

    assert sha(CHAT) == FIXED_SHA, f'restore failed: chat.js now hashes to {sha(CHAT)}'
    print(f'RESTORED sha256 {sha(CHAT)}', flush=True)

    # 4. green on the shipped bytes, then 5. the whole offline suite (which also rebuilds dist/client).
    run(['npm', 'run', 'build'], SCRATCH / 'build-final.log', 'build-final')
    if run(['npx', 'playwright', 'test', SPEC, '--output=artifacts/playwright/iter59-green-final'],
           SCRATCH / 'green-final.log', 'green-final') != 0:
        failures.append('green-final failed on the shipped bytes')
    if run(['npm', 'test'], SCRATCH / 'offline-final.log', 'offline-final') != 0:
        failures.append('the offline suite failed on the shipped bytes')

    print('LADDER ' + ('FAILED: ' + '; '.join(failures) if failures else 'COMPLETE'), flush=True)
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
