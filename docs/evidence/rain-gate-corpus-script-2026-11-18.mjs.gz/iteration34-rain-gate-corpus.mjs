// METHOD: contextBlocks from the scratch copy ../artifacts/chat-context-gate-patched.js (a copy of
// public/js/lib/chat-context.js with the weather gate widened), plus the shipped module for comparison, run
// 19 Nov. Widening a topic gate is only honest if the whole-word rules that subsection 17 established still
// hold, so this probe carries both directions: phrasings that must now reach the weather paragraph, and
// neighbour words that merely contain those letters and must still reach nothing. Self-checking; exits 1 on
// any wrong verdict.
const patched = process.argv[2] ?? './chat-context-gate-patched.js';
const shipped = process.argv[3] ?? '../public/js/lib/chat-context.js';
const { contextBlocks } = await import(patched);
const { contextBlocks: shippedBlocks } = await import(shipped);
const observations = {
  period: { start: '2024-01-01', end: '2024-12-31' },
  dates: ['2024-06-01', '2024-06-02', '2024-06-03'],
  location: { latitude: -31.89, longitude: 116.77 },
  retrievedAt: '2025-02-01T00:00:00Z',
  source: { id: 'nasa-power', title: 'NASA POWER exact data request', url: 'https://example.invalid/power' },
  parameters: {
    T2M: { label: 'Mean air temperature', units: '°C', latestAvailableDate: '2024-06-03', values: [12.1, 12.9, 13.4] },
    T2M_MIN: { label: 'Minimum air temperature', units: '°C', latestAvailableDate: '2024-06-03', values: [-1.4, -0.6, -0.2] },
    PRECTOTCORR: { label: 'Rainfall', units: 'mm/day', latestAvailableDate: '2024-06-03', values: [0, 3.4, 5.1] },
    ALLSKY_SFC_SW_DWN: { label: 'Solar irradiance', units: 'MJ/m^2/day', latestAvailableDate: '2024-06-03', values: [9.8, 10.2, 10.5] }
  }
};
const quoted = (fn, q) => {
  // Only the weather paragraph is under test here: a soil or water question with nothing loaded still
  // produces its own limitation block, and counting that as a weather leak would be a measurement error.
  const block = fn(q, { observations }, { topic: 'conditions' }).blocks.find(b => b.kind === 'historical weather evidence');
  return block ? block.text.match(/^([^:]+):/)?.[1] ?? 'weather' : '';
};
const want = [
  ['How much rain fell here last year?', 'Rainfall'], ['Did we get enough rain this season?', 'Rainfall'],
  ['The rain came late.', 'Rainfall'], ['It was rainy in March.', 'Rainfall'],
  ['Rain does not fall evenly here.', 'Rainfall'], ['How does the rain look for beans?', 'Rainfall'],
  ['The spring rains were short.', 'Rainfall'], ['Are the rainy months getting fewer?', 'Rainfall'],
  ['Did it freeze here in July?', 'Minimum air temperature'], ['Is freezing common here?', 'Minimum air temperature'],
  ['A frosty night, is that likely?', 'Minimum air temperature'], ['How much rain fell here? NASA figures', 'Rainfall'],
  ['Show me rainfall evidence', 'Rainfall'], ['Was there a frost?', 'Minimum air temperature'],
  ['Is there solar resource here?', 'Solar irradiance'], ['What was the temperature here?', 'Mean air temperature']
];
const mustNot = [
  'Tell me about the Australian grains industry', 'The train arrives at 6', 'What is the drainage like here?',
  'Restrain the dogs near the field', 'A brainstorm is not a plan', 'How long do freeze-dried beans keep?',
  'Is rain-fed maize viable here?', 'My rainfed field needs no irrigation', 'The drain system is old',
  'Tell me about grain pricing', 'Our farmer reported a soil pH of 6.5'
];
let failed = 0, before = 0;
for (const [q, series] of want) {
  const now = quoted(contextBlocks, q), then = quoted(shippedBlocks, q);
  if (then) before++;
  if (now !== series) { failed++; console.log(`WRONG  expected ${series}, got ${now || '(nothing)'} :: ${q}`); }
  else console.log(`${then ? 'KEPT   ' : 'ADDED  '} ${series.padEnd(24)} :: ${q}`);
}
for (const q of mustNot) {
  const now = quoted(contextBlocks, q);
  if (now) { failed++; console.log(`LEAKED weather evidence opened :: ${q} (${now})`); }
  else console.log(`CLEAN  (no weather paragraph)    :: ${q}`);
}
console.log(`POSITIVE ${want.filter(([q]) => quoted(contextBlocks, q)).length}/${want.length}, of which the shipped gate already reached ${before}`);
console.log(`NEGATIVE ${mustNot.filter(q => !quoted(contextBlocks, q)).length}/${mustNot.length} stay closed`);
console.log(failed ? `FAILURES ${failed}` : 'FAILURES 0');
process.exit(failed ? 1 : 0);
