#!/usr/bin/env python3
"""Attack the three tally rows iteration 60 added, plus the floor and one absent-needle, and prove each goes red."""
import hashlib
import re
import subprocess
import sys

TARGET = 'tests/documentation-evidence-index.test.js'
SUITE = ['node', '--test', TARGET]

ATTACKS = [
    ('a1-gate-wall-time', '260 passed (20.1m)', '260 passed (99.9m)',
     'docs/evidence/iter60-gate-2026-11-20.log.gz'),
    ('a2-offline-count', "'ℹ tests 262', 'ℹ pass 262'", "'ℹ tests 261', 'ℹ pass 261'",
     'docs/evidence/iter60-offline-final-2026-11-20.log.gz'),
    ('a3-guard-child-exit', "'DOCSGUARDS_CHILD_EXIT 0'", "'DOCSGUARDS_CHILD_EXIT 7'",
     'docs/evidence/iter60-docsguards-final-2026-11-20.log.gz'),
    ('a4-floor', 'TALLIES.length >= 59', 'TALLIES.length >= 1005',
     'the table carries '),
    ('a5-absent-needle', "absent: ['ℹ fail 1', 'GUARD_EXIT=1', 'DOCSGUARDS_ABORT']",
     "absent: ['ℹ pass 27', 'GUARD_EXIT=1', 'DOCSGUARDS_ABORT']",
     'docs/evidence/iter60-docsguards-final-2026-11-20.log.gz'),
]


def sha256(path):
    with open(path, 'rb') as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def run_suite():
    proc = subprocess.run(SUITE, capture_output=True, text=True)
    return proc.returncode, proc.stdout + proc.stderr


def fails(text):
    match = re.search(r'^ℹ fail (\d+)$', text, re.MULTILINE)
    return int(match.group(1)) if match else -1


original = open(TARGET, encoding='utf-8').read()
start_sha = sha256(TARGET)
print(f'CONTROL_TARGET_SHA_BEFORE {start_sha[:16]}')
detected = 0
for name, old, new, needle in ATTACKS:
    if original.count(old) != 1:
        print(f'ATTACK {name} REFUSED pattern occurs {original.count(old)} times, expected exactly 1')
        sys.exit(1)
    open(TARGET, 'w', encoding='utf-8').write(original.replace(old, new, 1))
    code, out = run_suite()
    red = fails(out)
    named = needle in out
    ok = code != 0 and red > 0 and named
    detected += 1 if ok else 0
    print(f'ATTACK {name} exit={code} fail_lines={red} names_target={named} DETECTED={"yes" if ok else "no"}')
    if not ok:
        print(f'GREEN - CONTROL FAILED {name}')
        print(out[-1200:])
    open(TARGET, 'w', encoding='utf-8').write(original)
    now = sha256(TARGET)
    print(f'ATTACK {name} RESTORED_IDENTICAL={str(now == start_sha).lower()}')

code, out = run_suite()
print(f'CONTROLS_RAN {len(ATTACKS)} CONTROLS_DETECTED {detected} CONTROLS_RED {detected}')
print(f'RESTORE_CHECK before={start_sha[:16]} now={sha256(TARGET)[:16]}')
print(f'AFTER_RESTORE exit={code} tests_fails={fails(out)}')
print(f"AFTER_RESTORE_SUMMARY {' '.join(l.strip() for l in out.splitlines() if l.startswith('ℹ tests ') or l.startswith('ℹ pass ') or l.startswith('ℹ fail '))}")
sys.exit(0 if code == 0 and detected == len(ATTACKS) else 1)
